/* ===== Available Filament Colors ===== */
const filamentColors = [
  { id: "black",   name: "Black",   hex: "#1a1a1a" },
  { id: "white",   name: "White",   hex: "#f5f5f5" },
  { id: "red",     name: "Red",     hex: "#e63939" },
  { id: "blue",    name: "Blue",    hex: "#2b6cb0" },
  { id: "green",   name: "Green",   hex: "#2f9e44" },
  { id: "orange",  name: "Orange",  hex: "#f76707" },
  { id: "yellow",  name: "Yellow",  hex: "#f59f00" },
  { id: "purple",  name: "Purple",  hex: "#9c36b5" },
  { id: "gray",    name: "Gray",    hex: "#868e96" },
  { id: "pink",    name: "Pink",    hex: "#e64980" },
  { id: "teal",    name: "Teal",    hex: "#12b886" },
  { id: "gold",    name: "Gold",    hex: "#e6a817" }
];

/* ===== Products =====
   To add your own models:
   1. Copy one of the objects below
   2. Change id, title, price, description, emoji
   3. Set which colors are available (or use allColors)
   4. Save and re-upload the file
*/
const allColors = filamentColors.map(c => c.id);

const products = [
  {
    id: 1,
    title: "Modular Desk Organizer",
    category: "functional",
    categoryLabel: "Functional",
    price: 24.00,
    emoji: "🗂️",
    description: "Stackable trays + pen holder. Fits most desks. Printed in durable PETG.",
    badge: null,
    colors: allColors
  },
  {
    id: 2,
    title: "Dragon Miniature (28mm)",
    category: "miniatures",
    categoryLabel: "Miniatures",
    price: 18.50,
    emoji: "🐉",
    description: "Highly detailed tabletop dragon. Supports included. Great for painting.",
    badge: "Popular",
    colors: ["black", "white", "red", "blue", "green", "gray", "gold"]
  },
  {
    id: 3,
    title: "Geometric Plant Pot",
    category: "home",
    categoryLabel: "Home & Decor",
    price: 22.00,
    emoji: "🪴",
    description: "Modern faceted design. Drainage hole included. Perfect for small plants.",
    badge: null,
    colors: allColors
  },
  {
    id: 4,
    title: "Phone Stand Pro",
    category: "gadgets",
    categoryLabel: "Gadgets",
    price: 14.00,
    emoji: "📱",
    description: "Adjustable angle, cable management slot. Works with all phones.",
    badge: null,
    colors: ["black", "white", "gray", "blue", "red", "teal"]
  },
  {
    id: 5,
    title: "Cable Management Clips (6-pack)",
    category: "functional",
    categoryLabel: "Functional",
    price: 9.50,
    emoji: "🔌",
    description: "Adhesive-ready clips for clean desk setups. Strong hold.",
    badge: "New",
    colors: ["black", "white", "gray"]
  },
  {
    id: 6,
    title: "Sci-Fi Terrain Set",
    category: "miniatures",
    categoryLabel: "Miniatures",
    price: 32.00,
    emoji: "🏙️",
    description: "Three modular pieces for 28–32mm games. Highly detailed.",
    badge: null,
    colors: ["black", "gray", "white", "blue", "purple"]
  },
  {
    id: 7,
    title: "Minimalist Wall Hook",
    category: "home",
    categoryLabel: "Home & Decor",
    price: 11.00,
    emoji: "🪝",
    description: "Strong & simple. Holds up to 5 kg. Clean modern look.",
    badge: null,
    colors: allColors
  },
  {
    id: 8,
    title: "Controller Stand",
    category: "gadgets",
    categoryLabel: "Gadgets",
    price: 16.50,
    emoji: "🎮",
    description: "Holds dual controllers + headset hook. Stable base.",
    badge: null,
    colors: ["black", "white", "red", "blue", "gray"]
  }
];

/* ===== State ===== */
let cart = JSON.parse(localStorage.getItem("printforge-cart")) || [];
let currentFilter = "all";
let selectedProduct = null;
let selectedColor = null;

/* ===== DOM ===== */
const productGrid = document.getElementById("productGrid");
const cartBtn = document.getElementById("cartBtn");
const cartDrawer = document.getElementById("cartDrawer");
const cartOverlay = document.getElementById("cartOverlay");
const closeCart = document.getElementById("closeCart");
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
const cartTotal = document.getElementById("cartTotal");
const checkoutBtn = document.getElementById("checkoutBtn");
const toast = document.getElementById("toast");
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");
const filterBtns = document.querySelectorAll(".filter-btn");

/* Modal elements */
const productModal = document.getElementById("productModal");
const modalOverlay = document.getElementById("modalOverlay");
const modalClose = document.getElementById("modalClose");
const modalEmoji = document.getElementById("modalEmoji");
const modalTitle = document.getElementById("modalTitle");
const modalDesc = document.getElementById("modalDesc");
const modalPrice = document.getElementById("modalPrice");
const colorOptions = document.getElementById("colorOptions");
const modalAddBtn = document.getElementById("modalAddBtn");
const selectedColorLabel = document.getElementById("selectedColorLabel");

/* ===== Helpers ===== */
function getColor(id) {
  return filamentColors.find(c => c.id === id) || filamentColors[0];
}

/* ===== Render Products ===== */
function renderProducts() {
  const filtered = currentFilter === "all"
    ? products
    : products.filter(p => p.category === currentFilter);

  productGrid.innerHTML = filtered.map(p => `
    <article class="product-card" data-id="${p.id}">
      <div class="product-image" data-id="${p.id}">
        ${p.emoji}
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ""}
      </div>
      <div class="product-body">
        <p class="product-category">${p.categoryLabel}</p>
        <h3 class="product-title">${p.title}</h3>
        <p class="product-desc">${p.description}</p>
        <div class="product-colors-preview">
          ${p.colors.slice(0, 6).map(cid => {
            const c = getColor(cid);
            return `<span class="color-dot" style="background:${c.hex}" title="${c.name}"></span>`;
          }).join("")}
          ${p.colors.length > 6 ? `<span class="color-more">+${p.colors.length - 6}</span>` : ""}
        </div>
        <div class="product-footer">
          <span class="product-price">$${p.price.toFixed(2)}</span>
          <button class="add-btn" data-id="${p.id}">Customize</button>
        </div>
      </div>
    </article>
  `).join("");

  // Open modal on card click or Customize button
  document.querySelectorAll(".product-card").forEach(card => {
    card.addEventListener("click", (e) => {
      // Don't trigger if clicking something else later
      openProductModal(+card.dataset.id);
    });
  });
}

/* ===== Product Modal ===== */
function openProductModal(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;

  selectedProduct = product;
  selectedColor = product.colors[0]; // default to first available

  modalEmoji.textContent = product.emoji;
  modalTitle.textContent = product.title;
  modalDesc.textContent = product.description;
  modalPrice.textContent = `$${product.price.toFixed(2)}`;

  // Build color swatches
  colorOptions.innerHTML = product.colors.map(cid => {
    const c = getColor(cid);
    const isActive = cid === selectedColor ? "active" : "";
    return `
      <button class="color-swatch ${isActive}" 
              data-color="${cid}" 
              style="--swatch-color: ${c.hex}"
              title="${c.name}"
              aria-label="${c.name}">
      </button>
    `;
  }).join("");

  updateSelectedColorLabel();

  // Color click handlers
  colorOptions.querySelectorAll(".color-swatch").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      selectedColor = btn.dataset.color;
      colorOptions.querySelectorAll(".color-swatch").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      updateSelectedColorLabel();
    });
  });

  productModal.classList.add("open");
  modalOverlay.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeProductModal() {
  productModal.classList.remove("open");
  modalOverlay.classList.remove("open");
  document.body.style.overflow = "";
  selectedProduct = null;
  selectedColor = null;
}

function updateSelectedColorLabel() {
  if (!selectedColor) return;
  const c = getColor(selectedColor);
  selectedColorLabel.textContent = c.name;
  selectedColorLabel.style.color = c.hex === "#f5f5f5" || c.hex === "#e6a817" ? "#ccc" : c.hex;
}

/* ===== Cart Functions ===== */
function saveCart() {
  localStorage.setItem("printforge-cart", JSON.stringify(cart));
  updateCartUI();
}

function addToCartWithColor() {
  if (!selectedProduct || !selectedColor) return;

  const color = getColor(selectedColor);
  const cartKey = `${selectedProduct.id}-${selectedColor}`;

  const existing = cart.find(item => item.cartKey === cartKey);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({
      cartKey,
      id: selectedProduct.id,
      title: selectedProduct.title,
      price: selectedProduct.price,
      emoji: selectedProduct.emoji,
      colorId: selectedColor,
      colorName: color.name,
      colorHex: color.hex,
      qty: 1
    });
  }

  saveCart();
  showToast(`${selectedProduct.title} (${color.name}) added to cart`);
  closeProductModal();
}

function removeFromCart(cartKey) {
  cart = cart.filter(item => item.cartKey !== cartKey);
  saveCart();
}

function changeQty(cartKey, delta) {
  const item = cart.find(i => i.cartKey === cartKey);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(cartKey);
  } else {
    saveCart();
  }
}

function updateCartUI() {
  const totalItems = cart.reduce((sum, i) => sum + i.qty, 0);
  cartCount.textContent = totalItems;

  if (cart.length === 0) {
    cartItems.innerHTML = `<p class="cart-empty">Your cart is empty</p>`;
  } else {
    cartItems.innerHTML = cart.map(item => `
      <div class="cart-item">
        <div class="cart-item-img">${item.emoji}</div>
        <div class="cart-item-info">
          <div class="cart-item-title">${item.title}</div>
          <div class="cart-item-meta">
            <span class="cart-color-dot" style="background:${item.colorHex}"></span>
            ${item.colorName} · $${item.price.toFixed(2)}
          </div>
          <div class="cart-item-actions">
            <button class="qty-btn" data-action="dec" data-key="${item.cartKey}">−</button>
            <span>${item.qty}</span>
            <button class="qty-btn" data-action="inc" data-key="${item.cartKey}">+</button>
            <button class="remove-btn" data-key="${item.cartKey}">Remove</button>
          </div>
        </div>
      </div>
    `).join("");

    cartItems.querySelectorAll(".qty-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        changeQty(btn.dataset.key, btn.dataset.action === "inc" ? 1 : -1);
      });
    });
    cartItems.querySelectorAll(".remove-btn").forEach(btn => {
      btn.addEventListener("click", () => removeFromCart(btn.dataset.key));
    });
  }

  const total = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  cartTotal.textContent = `$${total.toFixed(2)}`;
}

/* ===== Cart Open/Close ===== */
function openCart() {
  cartDrawer.classList.add("open");
  cartOverlay.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeCartDrawer() {
  cartDrawer.classList.remove("open");
  cartOverlay.classList.remove("open");
  document.body.style.overflow = "";
}

/* ===== Toast ===== */
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2200);
}

/* ===== Forms (demo) ===== */
document.getElementById("quoteForm").addEventListener("submit", e => {
  e.preventDefault();
  showToast("Quote request received! We'll reply within 24h.");
  e.target.reset();
});

document.getElementById("contactForm").addEventListener("submit", e => {
  e.preventDefault();
  showToast("Message sent. We'll get back to you soon.");
  e.target.reset();
});

checkoutBtn.addEventListener("click", () => {
  if (cart.length === 0) {
    showToast("Your cart is empty");
    return;
  }
  showToast("Demo only — connect Stripe/PayPal to accept payments");
});

/* ===== Filters ===== */
filterBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    filterBtns.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentFilter = btn.dataset.filter;
    renderProducts();
  });
});

/* ===== Mobile Menu ===== */
menuBtn.addEventListener("click", () => {
  nav.classList.toggle("open");
});

nav.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

/* ===== Event Listeners ===== */
cartBtn.addEventListener("click", openCart);
closeCart.addEventListener("click", closeCartDrawer);
cartOverlay.addEventListener("click", closeCartDrawer);

modalClose.addEventListener("click", closeProductModal);
modalOverlay.addEventListener("click", closeProductModal);
modalAddBtn.addEventListener("click", addToCartWithColor);

/* ===== Init ===== */
renderProducts();
updateCartUI();
